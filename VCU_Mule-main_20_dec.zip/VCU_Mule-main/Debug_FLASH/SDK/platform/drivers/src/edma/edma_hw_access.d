SDK/platform/drivers/src/edma/edma_hw_access.o: \
 ../SDK/platform/drivers/src/edma/edma_hw_access.c \
 ../SDK/platform/drivers/src/edma/edma_hw_access.h \
 ../SDK/platform/drivers/inc/edma_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h

../SDK/platform/drivers/src/edma/edma_hw_access.h:

../SDK/platform/drivers/inc/edma_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:
