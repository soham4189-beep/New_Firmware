################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
LD_SRCS := 
TODISASSEMBLE_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_UPPER_SRCS := 
TOPREPROCESS_SRCS := 
ASM_SRCS := 
C_SRCS := 
O_SRCS := 
S_UPPER_SRCS := 
EXECUTABLES := 
OBJS := 
SECONDARY_SIZE := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
BSP/Src \
Project_Settings/Startup_Code \
SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/startup \
SDK/S32K144_SDK_4.0.1/platform/devices \
SDK/platform/drivers/src/adc \
SDK/platform/drivers/src/clock/S32K1xx \
SDK/platform/drivers/src/edma \
SDK/platform/drivers/src/flexcan \
SDK/platform/drivers/src/interrupt \
SDK/platform/drivers/src/lpit \
SDK/platform/drivers/src/lptmr \
SDK/platform/drivers/src/pdb \
SDK/platform/drivers/src/pins \
SDK/platform/drivers/src/rtc \
SDK/platform/drivers/src/trgmux \
SDK/rtos/osif \
board \
src \

