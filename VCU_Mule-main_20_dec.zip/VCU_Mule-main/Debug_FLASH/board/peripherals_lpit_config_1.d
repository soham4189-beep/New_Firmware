board/peripherals_lpit_config_1.o: ../board/peripherals_lpit_config_1.c \
 ../board/peripherals_lpit_config_1.h \
 ../SDK/platform/drivers/inc/lpit_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h

../board/peripherals_lpit_config_1.h:

../SDK/platform/drivers/inc/lpit_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:
