board/clock_config.o: ../board/clock_config.c ../board/clock_config.h \
 ../SDK/platform/drivers/inc/clock.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h \
 ../SDK/platform/drivers/inc/../src/clock/S32K1xx/clock_S32K1xx.h

../board/clock_config.h:

../SDK/platform/drivers/inc/clock.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:

../SDK/platform/drivers/inc/../src/clock/S32K1xx/clock_S32K1xx.h:
