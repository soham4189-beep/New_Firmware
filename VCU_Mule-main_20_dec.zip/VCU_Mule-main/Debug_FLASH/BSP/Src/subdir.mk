################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/Src/CAN.c \
../BSP/Src/delay.c \
../BSP/Src/dma.c \
../BSP/Src/gear_shifter.c \
../BSP/Src/gpio.c \
../BSP/Src/rtc.c \
../BSP/Src/timer.c 

OBJS += \
./BSP/Src/CAN.o \
./BSP/Src/delay.o \
./BSP/Src/dma.o \
./BSP/Src/gear_shifter.o \
./BSP/Src/gpio.o \
./BSP/Src/rtc.o \
./BSP/Src/timer.o 

C_DEPS += \
./BSP/Src/CAN.d \
./BSP/Src/delay.d \
./BSP/Src/dma.d \
./BSP/Src/gear_shifter.d \
./BSP/Src/gpio.d \
./BSP/Src/rtc.d \
./BSP/Src/timer.d 


# Each subdirectory must supply rules for building sources it contributes
BSP/Src/%.o: ../BSP/Src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@BSP/Src/CAN.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


