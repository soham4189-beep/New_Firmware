BSP/Src/dma.o: ../BSP/Src/dma.c \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/sdk_project_config.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/clock_config.h \
 ../SDK/platform/drivers/inc/clock.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h \
 ../SDK/platform/drivers/inc/../src/clock/S32K1xx/clock_S32K1xx.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/pin_mux.h \
 ../SDK/platform/drivers/inc/pins_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_adc_config_1.h \
 ../SDK/platform/drivers/inc/adc_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_edma_config_1.h \
 ../SDK/platform/drivers/inc/edma_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_lptmr_1.h \
 ../SDK/platform/drivers/inc/lptmr_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_pdb_config_1.h \
 ../SDK/platform/drivers/inc/pdb_driver.h \
 C:/NXP/S32DS.3.5/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock_manager.h \
 C:/NXP/S32DS.3.5/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_trgmux_1.h \
 ../SDK/platform/drivers/inc/trgmux_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_flexcan_config_1.h \
 ../SDK/platform/drivers/inc/flexcan_driver.h ../SDK/rtos/osif/osif.h \
 ../SDK/platform/drivers/inc/edma_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_lpit_config_1.h \
 ../SDK/platform/drivers/inc/lpit_driver.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_flexcan_config_2.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_rtc_1.h \
 ../SDK/platform/drivers/inc/rtc_driver.h \
 ../SDK/platform/drivers/inc/interrupt_manager.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/dma.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/gear_shifter.h \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/Throttle_read.h

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/sdk_project_config.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/clock_config.h:

../SDK/platform/drivers/inc/clock.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:

../SDK/platform/drivers/inc/../src/clock/S32K1xx/clock_S32K1xx.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/pin_mux.h:

../SDK/platform/drivers/inc/pins_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_adc_config_1.h:

../SDK/platform/drivers/inc/adc_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_edma_config_1.h:

../SDK/platform/drivers/inc/edma_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_lptmr_1.h:

../SDK/platform/drivers/inc/lptmr_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_pdb_config_1.h:

../SDK/platform/drivers/inc/pdb_driver.h:

C:/NXP/S32DS.3.5/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock_manager.h:

C:/NXP/S32DS.3.5/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_trgmux_1.h:

../SDK/platform/drivers/inc/trgmux_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_flexcan_config_1.h:

../SDK/platform/drivers/inc/flexcan_driver.h:

../SDK/rtos/osif/osif.h:

../SDK/platform/drivers/inc/edma_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_lpit_config_1.h:

../SDK/platform/drivers/inc/lpit_driver.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_flexcan_config_2.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/board/peripherals_rtc_1.h:

../SDK/platform/drivers/inc/rtc_driver.h:

../SDK/platform/drivers/inc/interrupt_manager.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/dma.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/gear_shifter.h:

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/Throttle_read.h:
