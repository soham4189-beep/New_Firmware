src/drive_status_change.o: ../src/drive_status_change.c \
 D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/gear_shifter.h

D:/Electronics/Firmware/S32144/VCU_Mule-main_24th_Sept_10000torque_gear_shifter_issue_solve/VCU_Mule-main/BSP/Inc/gear_shifter.h:
