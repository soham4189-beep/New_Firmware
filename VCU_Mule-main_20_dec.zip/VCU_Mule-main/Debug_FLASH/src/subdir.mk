################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/Instrument_cluster.c \
../src/Throttle_control.c \
../src/drive_status_change.c \
../src/main.c 

OBJS += \
./src/Instrument_cluster.o \
./src/Throttle_control.o \
./src/drive_status_change.o \
./src/main.o 

C_DEPS += \
./src/Instrument_cluster.d \
./src/Throttle_control.d \
./src/drive_status_change.d \
./src/main.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/Instrument_cluster.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


